
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'dagogodboss',
  applicationName: 'job-board-api',
  appUid: 'cgTt2z1K8NBGwVxWQ5',
  orgUid: '44e36768-3899-48ec-8637-1d46bc6f5d78',
  deploymentUid: '43b48f4e-418f-482a-9405-aef8027f8d74',
  serviceName: 'hoc-jobboard-api',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'hoc-jobboard-api-dev-app', timeout: 29 };

try {
  const userHandler = require('./dist/main.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}